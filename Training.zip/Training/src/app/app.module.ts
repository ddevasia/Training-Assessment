import { NgModule } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { TrainingFormComponent } from './components/trainingFrm.validation';
import { TrainingService } from './Service/training.service';
 

@NgModule({
   imports: [BrowserModule,HttpModule],
   declarations: [AppComponent, TrainingFormComponent],
  providers: [{ provide: APP_BASE_HREF, useValue: '/' }, TrainingService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
