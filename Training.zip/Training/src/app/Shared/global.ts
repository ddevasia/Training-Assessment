﻿export class Global {
    public static BASE_USER_ENDPOINT = 'api/userapi/';
    public static SUCCESS_MESSAGE = 'Data Saved Sucessfully';
    public static ERROR_MESSAGE = 'There is some issue in saving records!';
    public static ERROR_MESSAGE_DATE = 'Please Enter Proper Dates';
}