"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/* tslint:disable:member-ordering */
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var global_1 = require("../Shared/global");
var TrainingFormComponent = (function () {
    function TrainingFormComponent(fb) {
        this.fb = fb;
        this.createForm();
    }
    TrainingFormComponent.prototype.createForm = function () {
        this.trainingFrm = this.fb.group({
            startDate: ['', forms_1.Validators.required],
            endDate: ['', forms_1.Validators.required]
        }, { validator: this.dateLessThan('startDate', 'endDate') });
    };
    TrainingFormComponent.prototype.dateLessThan = function (from, to) {
        return function (group) {
            var f = group.controls[from];
            var t = group.controls[to];
            if (f.value > t.value) {
                return {
                    dates: global_1.Global.ERROR_MESSAGE_DATE
                };
            }
            return {};
        };
    };
    TrainingFormComponent.prototype.onSubmit = function () {
        console.log("Sucess");
        console.log(this.trainingFrm);
        console.log(this.trainingFrm.value);
    };
    TrainingFormComponent.prototype.dismiss = function () {
        this.trainingFrm.reset();
    };
    return TrainingFormComponent;
}());
TrainingFormComponent = __decorate([
    core_1.Component({
        selector: 'trainingFrm.validation',
        templateUrl: './training.component.html'
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder])
], TrainingFormComponent);
exports.TrainingFormComponent = TrainingFormComponent;
//# sourceMappingURL=trainingFrm.validation.js.map