﻿/* tslint:disable:member-ordering */
import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Training } from '../Model/training';
import { Global } from '../Shared/global';

@Component({
    selector: 'trainingFrm.validation',
    templateUrl: './training.component.html'
})
export class TrainingFormComponent {

    trainingFrm: FormGroup

    constructor(private fb: FormBuilder) {
        this.createForm();
    }

    createForm() {
        this.trainingFrm = this.fb.group({
            startDate: ['', Validators.required],
            endDate: ['', Validators.required]
        }, { validator: this.dateLessThan('startDate', 'endDate') });
    }

    dateLessThan(from: string, to: string) {
        return (group: FormGroup): { [key: string]: any } => {
            let f = group.controls[from];
            let t = group.controls[to];
            if (f.value > t.value) {
                return {
                    dates: Global.ERROR_MESSAGE_DATE
                };
            }
            return {};
        }
    }

    onSubmit() {
        console.log("Sucess")
        console.log(this.trainingFrm)
        console.log(this.trainingFrm.value)
    }

    dismiss(){
        this.trainingFrm.reset();
    }


}