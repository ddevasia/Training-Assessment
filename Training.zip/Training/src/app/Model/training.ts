﻿export interface Training {
    trainingId: number,
    trainingName: string,
    startDate: Date,
    endDate: Date
}